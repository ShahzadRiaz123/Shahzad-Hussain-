const $ = (q, el=document) => el.querySelector(q);
const $$ = (q, el=document) => [...el.querySelectorAll(q)];

async function loadProfile(){
  const res = await fetch('assets/data/profile.json', {cache:'no-store'});
  const d = await res.json();

  $('#name').textContent = d.name;
  $('#name2').textContent = d.name;
  $('#name3').textContent = d.name;
  $('#title').textContent = d.title;

  $('#tagline').textContent = d.tagline;

  $('#phone').textContent = d.contact.phone;
  $('#phone').href = 'tel:' + d.contact.phone.replace(/\s/g,'');
  $('#phone2').textContent = d.contact.phone;
  $('#phone2').href = 'tel:' + d.contact.phone.replace(/\s/g,'');
  $('#callBtn').href = 'tel:' + d.contact.phone.replace(/\s/g,'');

  $('#email').textContent = d.contact.email;
  $('#email').href = 'mailto:' + d.contact.email;
  $('#email2').textContent = d.contact.email;
  $('#email2').href = 'mailto:' + d.contact.email;
  $('#mailBtn').href = 'mailto:' + d.contact.email;

  $('#tempAddr').textContent = d.contact.temporary_address;
  $('#permAddr').textContent = d.contact.permanent_address;

  $('#objective').textContent = d.objective;
  $('#objective2').textContent = d.objective;

  // Languages chips
  const langs = $('#langs');
  langs.innerHTML = '';
  d.languages.forEach(l => {
    const s = document.createElement('span');
    s.className = 'chip';
    s.textContent = l;
    langs.appendChild(s);
  });

  // Experience
  const xp = $('#xp');
  xp.innerHTML = '';
  d.experience.forEach(item => {
    const el = document.createElement('article');
    el.className = 'xp reveal';
    el.innerHTML = `
      <div class="xp__when">${item.start} — ${item.end}</div>
      <div>
        <h3 class="xp__role">${item.role}</h3>
        <p class="xp__org">${item.org}</p>
        ${item.highlights && item.highlights.length ? `
          <ul class="xp__hl">
            ${item.highlights.map(h => `<li>${h}</li>`).join('')}
          </ul>` : ``}
      </div>`;
    xp.appendChild(el);
  });

  // Education
  const edu = $('#edu');
  edu.innerHTML = '';
  d.education.forEach(e => {
    const el = document.createElement('div');
    el.className = 'card reveal';
    el.innerHTML = `
      <h3>${e.degree}</h3>
      <p class="muted">${e.school}</p>
      <div class="row" style="margin-top:12px">
        <span class="pill">Year: ${e.year}</span>
        <span class="pill">Score: ${e.score}</span>
      </div>`;
    edu.appendChild(el);
  });

  // Skills
  const sg = $('#skillsGrid');
  sg.innerHTML = '';
  d.skills.forEach(s => {
    const el = document.createElement('div');
    el.className = 'card reveal';
    el.innerHTML = `<h3>${s}</h3><p class="muted">Practical, patient‑focused and reliable.</p>`;
    sg.appendChild(el);
  });

  // Update page title/description
  document.title = `${d.name} — ${d.title}`;
}

function setupTheme(){
  const key = 'portfolio_theme';
  const btn = $('#themeBtn');
  const apply = (t) => {
    document.documentElement.dataset.theme = t;
    localStorage.setItem(key, t);
  };
  const saved = localStorage.getItem(key);
  if(saved) apply(saved);
  else {
    const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
    apply(prefersLight ? 'light' : 'dark');
  }
  btn.addEventListener('click', () => {
    const cur = document.documentElement.dataset.theme || 'dark';
    apply(cur === 'dark' ? 'light' : 'dark');
  });
}

function setupMenu(){
  const menuBtn = $('#menuBtn');
  const nav = $('#nav');
  if(!menuBtn || !nav) return;
  menuBtn.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', String(isOpen));
  });
  $$('#nav a').forEach(a => a.addEventListener('click', ()=> {
    nav.classList.remove('open');
    menuBtn.setAttribute('aria-expanded','false');
  }));
}

function setupReveal(){
  const els = $$('.reveal');
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){ e.target.classList.add('is-in'); io.unobserve(e.target); }
    })
  }, {threshold: 0.12});
  els.forEach(el=>io.observe(el));
}

function setupContactForm(){
  const form = $('#contactForm');
  if(!form) return;
  form.addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const fd = new FormData(form);
    const name = fd.get('fromName');
    const email = fd.get('fromEmail');
    const msg = fd.get('message');
    const to = $('#email2').textContent || '';
    const subject = encodeURIComponent(`Portfolio Contact — ${name}`);
    const body = encodeURIComponent(`From: ${name} <${email}>\n\n${msg}`);
    window.location.href = `mailto:${to}?subject=${subject}&body=${body}`;
  });
}

$('#year') && ($('#year').textContent = String(new Date().getFullYear()));

loadProfile().then(()=>{
  setupReveal();
}).catch(()=>{ /* ignore */ });

setupTheme();
setupMenu();
setupContactForm();
